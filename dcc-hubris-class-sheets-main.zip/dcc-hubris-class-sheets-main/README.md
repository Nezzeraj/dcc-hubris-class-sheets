# Hubris sheets for Dungeon Crawl Classics in Foundry VTT

Expands the [Dungeon Crawl Classics system](https://github.com/cyface/foundryvtt-dcc/) for the [Foundry Virtual Tabletop](https://foundryvtt.com) to include Hubris class sheets.

Manifest URL: https://github.com/Nezzeraj/dcc-hubris-class-sheets/blob/main/dcc-hubris-classes/module.json

Hubris available here: https://preview.drivethrurpg.com/en/product/202811/hubris-a-world-of-visceral-adventure-limited-edition-cover

##### Maintainers

- Christopher Rowe (@nezzeraj)

##### Thanks to

- Steve B (@Steve B)
- Mike Evans
- Crawl! Sheet module developers
