export const hubris = {};

hubris.avarianPaths = {
    scoundrel: "Avarian.PathsScoundrel",
    trickster: "Avarian.PathsTrickster"
};